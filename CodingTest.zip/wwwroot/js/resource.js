﻿angular.module('accountsApp', [])
    .controller('accountsController', function($scope, $http) {
        $http.get('https://frontiercodingtests.azurewebsites.net/api/accounts/getall')
            .then(function (response) {
                $scope.accounts = response.data;
            });
    });